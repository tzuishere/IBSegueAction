import UIKit

struct Question
{
    let question: String
    let options: [String]
    let correctAnswer:Int
}

class ViewControllerA1: UIViewController
{
    @IBOutlet weak var numberLabel: UILabel!
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet var optionButtons: [UIButton]!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //設定問題集合
        setupQuestions()
        //加載初始問題
        loadQuestion()
    }
    
    //變數用於追蹤玩家的得分，初始值為0
    var scoreA1 = 0
    //儲存所有問題的陣列
    var questions:[Question] = []
    //追蹤當前顯示的問題的索引
    var currentQuestionIndex = 0
    {   //根據currentQuestionIndex的變化，更新問題
        didSet { loadQuestion() }
    }

    //設定問題
    func setupQuestions()
    {
        questions = [
            Question(question: "日本🇯🇵的首都在哪裡？", options: ["大阪","東京","京都"], correctAnswer: 1),
            Question(question: "美國🇺🇸的首都在哪裡？",options: ["華盛頓","紐約","洛杉磯"], correctAnswer: 0),
            Question(question: "澳洲🇦🇺的首都在哪裡？",options: ["墨爾本","雪梨","坎培拉"], correctAnswer: 2),
            Question(question: "西班牙🇪🇸的首都在哪裡？",options: ["巴塞隆那","馬德里","瓦倫西亞"], correctAnswer: 1),
            Question(question: "土耳其🇹🇷的首都在哪裡？",options: ["伊斯坦堡","伊茲密爾","安卡拉"], correctAnswer: 2),
            Question(question: "巴西🇧🇷的首都在哪裡？",options: ["里約熱內盧","聖保羅","巴西利亞"], correctAnswer: 2),
            Question(question: "中國🇨🇳的首都在哪裡？",options: ["北京","南京","上海"], correctAnswer: 0),
            Question(question: "加拿大🇨🇦的首都在哪裡？",options: ["溫哥華","渥太華","蒙特婁"], correctAnswer: 1),
            Question(question: "瑞士🇨🇭的首都在哪裡？",options: ["伯恩","日內瓦","蘇黎世"], correctAnswer: 0),
            Question(question: "印度🇮🇳的首都在哪裡？",options: ["孟買","加爾各答","新德里"], correctAnswer: 2),
        ]
    }
    
    //更新問題
    func loadQuestion()
    {   //如果題目還沒結束(尚未到第10題)
        if currentQuestionIndex < 10
        {   //取得目前題目
            let question = questions[currentQuestionIndex]
            //更新題號
            numberLabel.text = "第「\(currentQuestionIndex + 1)」題"
            //更新顯示的問題描述
            questionLabel.text = question.question
            //更新選項按鈕的標題(將question.options陣列中的選項，設定到optionButtons陣列中每個按鈕的標題上)
            for (index, optionButton) in optionButtons.enumerated()
            {   //setTitle(_:for:)方法，使按鈕在不同狀態下呈現不同的文字內容
                optionButton.setTitle(question.options[index], for: .normal)
            }
        }
        else
        {   //若所有問題回答完畢，執行Segue到結果畫面
            self.performSegue(withIdentifier: "showResultSegueA", sender: nil)
        }
    }
    
    //點擊答案的按鈕
    @IBAction func optionButtonTapped(_ sender: UIButton)
    {   //使用guard陳述式進行可選綁定，以確保成功取得選取的按鈕索引selectedIndex 後，才繼續執行後續的程式碼
        guard let selectedIndex = optionButtons.firstIndex(of: sender)
        else { return }
        
        let question = questions[currentQuestionIndex]
        //如果選取的答案正確，就會加一分
        if question.correctAnswer == selectedIndex
        {
            scoreA1 += 1
        }
        //切換到下一個問題
        currentQuestionIndex += 1
    }
    
    //將分數透過resultSegueActionA，從ViewControllerA1傳遞給viewControllerA2
    @IBSegueAction func resultSegueActionA(_ coder: NSCoder) -> ViewControllerA2?
    {
    let viewControllerA2 = ViewControllerA2(coder: coder)
        
        viewControllerA2?.scroeA2 = self.scoreA1
        
        return viewControllerA2
    }
}
