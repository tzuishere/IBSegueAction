import UIKit

class ViewControllerA2: UIViewController
{   //顯示「分數的標籤」
    @IBOutlet weak var scoreLabel: UILabel!
    //紀錄「答對的題數」
    var scroeA2:Int = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        //將「答對的題數」顯示在「分數的標籤」上
        scoreLabel.text = "你答對\(scroeA2)題"
    }
}
